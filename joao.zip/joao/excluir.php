<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test"; // Altere para o nome do seu banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Excluir professor
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Converte para inteiro para segurança
    $sql = "DELETE FROM professores WHERE id=?";
    
    // Usando prepared statement para evitar injeção de SQL
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo "Professor excluído com sucesso!";
    } else {
        echo "Erro ao excluir: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "ID do professor não fornecido.";
}

$conn->close();

// Redirecionar de volta para a página de cadastro após a exclusão
header("Location: cadastro.php");
exit();
?>