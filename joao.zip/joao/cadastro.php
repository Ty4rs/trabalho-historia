<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test"; // Altere para o nome do seu banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Cadastrar professor
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $titulacao = $_POST['titulacao'];
    $telefone = $_POST['telefone'];

    // Inserir professor no banco de dados
    $sql = "INSERT INTO professores (nome, titulacao, telefone) VALUES (?, ?, ?)";
    
    // Usando prepared statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nome, $titulacao, $telefone);
    
    if ($stmt->execute()) {
        echo "Professor cadastrado com sucesso!";
    } else {
        echo "Erro: " . $stmt->error;
    }
    $stmt->close();
}

// Listar professores
$sql = "SELECT * FROM professores";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Professores</title>
</head>
<body>
    <h1>Cadastro de Professores</h1>
    <form method="POST">
        Nome: <input type="text" name="nome" required><br>
        Titulação: 
        <select name="titulacao" required>
            <option value="Graduação">Graduação</option>
            <option value="Mestrado">Mestrado</option>
            <option value="Doutorado">Doutorado</option>
        </select><br>
        Telefone: <input type="text" name="telefone"><br>
        <input type="submit" value="Cadastrar">
    </form>

    <h2>Listagem de Professores</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Titulação</th>
            <th>Telefone</th>
            <th>Ações</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['nome']; ?></td>
                    <td><?php echo $row['titulacao']; ?></td>
                    <td><?php echo $row['telefone']; ?></td>
                    <td>
                        <a href="excluir.php?id=<?php echo $row['id']; ?>">Excluir</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">Nenhum professor cadastrado.</td>
            </tr>
        <?php endif; ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>